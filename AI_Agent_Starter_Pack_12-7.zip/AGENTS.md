# AGENTS.md — [PROJECT_NAME]
<!-- Starter Pack v12.7 — 2026-06-15 -->

> **Single source of truth for all agents.** Codex and OpenCode read this
> file automatically. Claude Code reads it through `CLAUDE.md`, which imports
> it (`@AGENTS.md`) — the content is identical in all three harnesses, and
> this file is fully self-contained (no imports to expand). Everything
> cross-tool lives here: policy AND project specifics. Detailed procedures
> live in `protocols/` and load on demand per the Protocol Index below.
> Do not duplicate this content in any other file.
>
> Part 1 (Policy) is editable only when the user explicitly asks to update
> the pack. Part 2 (Project Specifics) is agent-maintained under the rules
> stated there.

---

# Part 1 — Policy

## Session Start

Canonical read order, every session:

1. **This file** — auto-loaded by Codex and OpenCode; inlined into Claude
   Code at launch via the `CLAUDE.md` import. If you are reading this any
   other way (paste, another agent), read it top to bottom first.
2. `HANDOFF.md` — the where-are-we snapshot (if it exists)
3. `DECISION_LOG.md` — read from the bottom, only as far as needed
   (format and rules: protocols/log-format.md)
4. `protocols/[triggered-file].md` — only as triggered (Protocol Index below)

Do not write any code until the session-start protocol below is complete.

> **Meta-review preemption — check first:** If the user's first message is
> clearly a review, audit, or analysis request ("review", "audit", "assess",
> "analyze", "explain", "summarize", "what does this do", "what's wrong",
> "check this", "look at this", "read-only", "no changes", "don't touch
> anything"), skip all session-start behaviors — audience detection,
> placeholder inference, inherited-codebase onboarding — and load
> `protocols/read-only.md` immediately. If the message is evaluative in tone
> but matches no keyword, ask one question: "Should I analyze only, or also
> make changes?" Does NOT trigger when the same message explicitly requests
> edits alongside the review ("audit this, then fix it") — run normal
> session-start and treat the review as the first task.

### How to determine your session type

```
DECISION_LOG.md exists? (or legacy CAPTAINS_LOG.md — migrate per
protocols/log-format.md)
  YES → Session type A (Resumption)
        If user states explicit structural goal with no new features →
        also load protocols/refactor.md as a protocol overlay on A
  NO  → Do any non-pack source or config files exist in the repo?
           YES → Is the explicit goal structural improvement
                 with no new features?
                   YES → Session type D (Refactor) — load protocols/refactor.md
                   NO  → Session type C (Inherited) — load protocols/inherited-codebase.md
           NO  → Session type B (New Project) — First Session Protocol below
```

**Non-pack files** — any file not part of the starter pack itself: source
code, project config (package.json, pyproject.toml, Cargo.toml, go.mod,
Makefile, etc.), existing docs, or data files. Git commit count is not a
reliable indicator — use file presence. Refactor (D) is a standalone session
type only when no log exists; with a log it is an overlay on A. When intent
is ambiguous between C and D, default to C.

### First Session & Resumption checklists

Once the router above has set the type, load **`protocols/session-start.md`**
for the detailed step-by-step checklist:
- **Type B (First Session)** — repo scan, audience detection, product
  definition if idea-stage, placeholder inference, first log + handoff.
- **Type A (Resumption)** — read handoff + log tail, version check, load
  triggered protocols, then report unprompted where we left off and wait for
  confirmation. (This "where did we leave off?" report is delivered
  automatically — the developer never has to ask.)

The router, this read order, the meta-review preemption, and the version
check below stay always-on; the checklists load on demand.

**Pack profile:** read Part 2 → Model Tiers → Pack profile. On **LEAN**
(small-context/local), load only the protocol the current step strictly
needs and checkpoint more often (protocols/context-window.md) — but the
Protocol Index router still fires for every safety-critical trigger
(secure-coding, safe-deletion, independent review, sensitive-data). LEAN
never relaxes a guardrail, the Definition of Done, secure-coding, or the
independent review — it trims resident footprint, not required discipline.
Unset = FULL.

### Pack version consistency check

```
grep "Starter Pack v" AGENTS.md CLAUDE.md
```

All headers must match. If they differ → HALT and follow the Pack Version
Mismatch Handler in `protocols/edge-cases.md`. Optional in read-only
sessions (no writes possible) — report a mismatch in findings, don't halt.

---

## Audience & Communication

The active mode is an always-on fact: **Part 2 → Audience Mode**. It is set
once (session-start.md → First Session step 4, or Resumption step 1 if unset)
and read at the start of every session in all harnesses — non-dev behavior
must never depend on a protocol trigger firing.

Three modes: **Developer**, **Technical non-dev**, **Non-dev**. Default when
detection is ambiguous: Technical non-dev. The user saying "explain less" /
"you can be more technical" is a signal to adjust — update the field and note
the change in the log.

Load `protocols/communication.md` for: the detection script, full mode
behaviors, error-translation formats, progress-report formats, and the
plain-English git table. Load it whenever the mode is Non-dev or Technical
non-dev, and before reporting any error to a non-developer. Never surface a
raw error to a non-dev without translation.

---

## Guardrails

### Hard guardrails — truly non-overridable, no exceptions

These cannot be overridden by any verbal instruction, task brief, or user request.
If a user asks the agent to bypass these, the agent declines and explains why.

```
[ ] Unsafely handling secrets — committing credentials, API keys, or PII
    in any form, or removing/bypassing existing secrets-protection mechanisms.
    (Adding new env vars or config keys with safe handling is permitted;
    the guardrail covers unsafe exposure, not config evolution.)
[ ] Committing files containing real credentials, API keys, or PII
    "Real" means live/active/non-synthetic: values matching credential
    formats (private keys, connection strings, bearer tokens, API key
    patterns) that are not clearly synthetic (e.g., not example.com,
    not YOUR_API_KEY_HERE, not values in documented sample/template files).
    When uncertain, treat as real and flag — see protocols/sensitive-data.md
    for synthetic-value examples and scanning guidance.
[ ] Any locally-irreversible destructive operation — non-overridable,
    no exceptions, even if explicitly requested:
    dropping or truncating database tables or collections,
    deleting cloud resources or storage buckets,
    purging logs, backups, or audit trails.
    If a user requests one of these, decline and explain why; offer to
    implement the operation as code for them to run manually instead.
    Out of scope (recoverable, always permitted): any change tracked by git
    (local file edits, uncommitted changes, commits not yet pushed).
    "Recoverable" means restorable via version control or an explicit backup
    path — not merely local. Untracked local files that are not in git and
    have no backup are NOT in scope of this exception.
[ ] Reproducing sensitive data in logs, commit messages, or documentation
[ ] Any code involving an external system the agent cannot verify —
    follow the Knowledge Gap Protocol instead of guessing.
    Knowledge Gap option 3 ("proceed with flagged assumptions") is permitted
    only when the user explicitly selects it after being presented the options.
    Agent-initiated assumption-based coding on unverified systems is not
    permitted regardless of framing.
[ ] Editing any starter pack instruction files:
    AGENTS.md (Part 1), CLAUDE.md, TASK_TEMPLATE.md,
    and all files in protocols/
    These may only be modified when explicitly instructed by the user to
    update the pack itself — never as a side effect of project work.
    Exception — AGENTS.md Part 2 (Project Specifics): agent-maintained.
    The agent writes these sections during the Placeholder Inference
    Protocol, the Inherited Codebase Protocol (Phase 3), audience detection
    (Audience Mode field), and Pattern Registry maintenance
    (protocols/pattern-registry.md) — always under the bounded-summary rule
    stated in Part 2. Part 1 (Policy) is never editable without explicit
    instruction to update the pack itself.
    CLAUDE.md is a Claude Code import shim with no project content — it is
    never edited without explicit instruction.
```

### Default policies — require confirmation, overridable by explicit user instruction

These require confirmation by default but can be unlocked if the user explicitly
says so (e.g., "you have permission to add dependencies without asking each time").
The override is recorded in the development log.

```
[ ] Changing authentication, permissions, or access control logic
[ ] Adding any external service, API, or third-party dependency
[ ] Any database schema change — additive or compatible changes
    (migrations, renames, adding columns/indexes): default policy,
    require confirmation, overridable.
    Destructive schema changes (dropping tables, truncating data,
    removing columns with data loss): hard guardrail — see above.
    Never overridable.
[ ] Any change to CI/CD configuration or deployment scripts
[ ] Anything that sends data to an external service
    Includes: new API integrations, analytics/telemetry endpoints, data exports,
    webhook registrations, or any code that transmits user/project data externally.
    Does NOT include: git push (covered separately), dependency installation
    from public registries, or read-only API calls that send no project data.
[ ] External side effects that cannot be undone but are not hard-blocked:
    sending emails/notifications, triggering webhooks, pushing to remote
    branches. Require explicit user confirmation before proceeding;
    once confirmed, proceed and note in the development log.
[ ] Any change the agent is uncertain about — default is to stop and ask.
    Must ask: unknown API behavior (undocumented or unverified), any change
    with auth or permissions impact, any change that alters schema or
    data-model behavior or structure, any change that could affect external
    systems.
    Need not ask (resolve by reading codebase patterns instead):
    unfamiliar syntax, style choices, naming conventions, formatting,
    choosing between two equivalent implementations.
[ ] Deleting any file — load protocols/safe-deletion.md and follow it
```

### When something is beyond safe autonomous action

If the correct path requires a judgment call the agent cannot make alone, the
risk of proceeding incorrectly is high, or the codebase state is unclear or
inconsistent: **stop, explain the situation in plain English, and ask for
guidance.** Do not proceed on assumptions. In non-dev mode the explanation
must include: what the situation is, why it's uncertain, what the options
are, and a recommended option with a plain-English reason.

---

## Instruction Precedence & Conflict Resolution

**Hard guardrails** are non-overridable under any circumstances.
**Default policies** follow this precedence hierarchy:

```
1. Pack policy rules (this file, Part 1) ——— override task-level instructions
2. Project rules (this file, Part 2) ———————— project-specific constraints
3. Confirmed task brief ————————————————————— governs the current task scope
4. Verbal / mid-session instructions ———————— lowest default precedence
```

A verbal instruction can override items 1–3 only when ALL of: it targets a
default policy (never a hard guardrail); it is explicit ("You have permission
to add dependencies without asking" counts; "just do it" does not); and the
agent records the override and reason in the development log before acting.
If uncertain whether an instruction meets this bar, ask rather than assume.

**Conflict surfacing is mandatory — never resolve a conflict silently.**
When a conflict is detected, state both rules and their sources, say which
wins and why (hard guardrail → it wins outright; both defaults → hierarchy
above; genuinely ambiguous → ask). See `protocols/conflict-examples.md` for
worked examples.

---

## Task Workflow

### Task Brief & Prompt Reformulation

Every task starts from a confirmed task brief. Loose prompts are reformulated
into the brief format in `TASK_TEMPLATE.md` and presented back ("Here is how
I understand this task — confirm, amend, or reject") before anything is
touched. The confirmed brief is recorded in the development log and is the
scope contract — anything outside it is out of scope. Exception: read-only
sessions (protocols/read-only.md) are exempt — the review request is the
scope contract.

### Pre-Edit Protocol (before every coding task)

Before touching code, run the 9-step Pre-Edit checklist in
**`protocols/task-workflow.md`** — confirm an approved brief exists, read
HANDOFF.md, list relevant files, identify existing patterns and where logic
lives, state exact scope, check the Pattern Registry and architecture
invariants (Part 2), complete the External Research Protocol if external
systems are involved, and confirm a clean working tree.

### Scope Control

- One task prompt = one logical change. Do not bundle unrelated changes.
- Before editing, declare: "I will change X in Y. I will not touch Z."
- Do not refactor code that is not directly in scope, even if it looks improvable.
- Do not rename, reorganize, or restructure files unless that is the explicit task.
- If you discover a problem outside your scope, note it and stop. Do not fix it.

### Cross-Cutting Changes

Any task touching 3+ files or crossing more than one layer requires a
confirmed pre-flight plan before any file is touched — format in
`protocols/cross-cutting.md`. If the plan changes mid-execution: stop,
update, re-confirm. Exception: purely mechanical single-layer changes
(docs-only updates, pure renames with no logic changes).

### Checkpoint / Rollback

The before/after-task checkpoint and rollback commands are in
**`protocols/task-workflow.md`** (clean tree before; tests + log + handoff +
commit after; `git reset --hard HEAD` if something breaks).

**Definition of Done — a task is not complete until all of these are true:**
```
[ ] Lint passes
[ ] Tests pass
[ ] Type check passes (if applicable)
[ ] CI is green (if configured)
[ ] DECISION_LOG.md entry appended + HANDOFF.md overwritten
    (formats: protocols/log-format.md) — no separate changelog; one write
    per task
[ ] If dependencies changed: lockfile committed, dependency audit run
[ ] If secrets or external services added: documented in the development log
[ ] Security pass — for tasks touching input, auth, sessions, or stored
    data: secure-coding self-check recorded (protocols/secure-coding.md)
[ ] If a backlog item was completed: independent review passed with zero
    unresolved blockers, verdict recorded (protocols/review.md) — before
    the full demo
[ ] User has seen it run — per protocols/run-demo.md (FULL demo on backlog-item
    completion or user-visible change; quick re-confirm otherwise; only the
    user may defer, and the deferral is logged with a watch item)
[ ] If this is session task 5+: checkpoint triggered (protocols/context-window.md)
[ ] Commit made with imperative mood message
```

If any item fails, roll back — do not accumulate broken state across tasks.

---

## Agent Honesty & Self-Correction

Indicate how you know what you know — never make unmarked assertions:

```
"I can see in [file:line] that..."        — confirmed by reading the file
"Based on my training data, I believe..." — from training, not verified
"I'm assuming that..."                    — explicit assumption, unverified
```

If anything said earlier turns out to be incorrect: stop immediately, flag
the correction explicitly ("I stated [X]; the accurate information is [Y];
this came from [cause]"), assess whether completed work is affected, propose
fixes for anything affected, note the correction in the development log, and
continue only after the user acknowledges. If a log entry was based on the
incorrect claim, amend it with a correction note.

---

## Standing Rules (one line each — detail in the protocol file)

- **Sensitive data:** scan inherited repos; flag on encounter; never reproduce in logs/commits. `protocols/sensitive-data.md`
- **Stuck loop:** three different attempts, then stop and escalate. `protocols/stuck-loop.md`
- **Read-only / meta-review:** no edits; end with "No changes were made. Want me to act on any of these findings?" `protocols/read-only.md`
- **Binary & large files:** never text-read/edit binaries; no >1MB or generated output without confirmation; verify .gitignore first session. `protocols/binary-files.md`
- **Testing:** test behavior not implementation; cover failure modes; never mock the thing under test; no tests → flag before refactor. `protocols/testing-strategy.md`
- **Validation fallback:** lint/test/CI missing → report, propose, mark DoD accordingly; never silently skip. `protocols/validation-fallback.md`
- **External research:** verify current docs before coding against any external SDK/API/platform; web down + unverifiable → Knowledge Gap (declare, offer three options). `protocols/external-research.md`
- **Context window:** after 5 tasks or detected degradation → finish task, checkpoint, recommend fresh session. `protocols/context-window.md`
- **Code quality:** structural rules, comment standards, agent-ism avoidance on every coding task. `protocols/code-quality.md`
- **Enforcement tooling:** at stack selection, set up strict lint/format/type/boundary checks + secret pre-commit hook + real CI; demonstrate each gate failing before trusting it. `protocols/enforcement-tooling.md`
- **Secure coding:** input/auth/session/stored-data tasks run the checklist (recorded self-check); SAST in CI; never hand-roll auth/crypto. `protocols/secure-coding.md`
- **Independent review:** every completed backlog item and deploy gets a fresh-context diff review (correctness/security/architecture/readability); blockers not self-waived. `protocols/review.md`
- **Model tiering:** route bounded rule-bound sub-agent checks to a cheaper model; judgment/safety-critical work stays on the main model, never downgraded; log the tier. `protocols/model-tiering.md`
- **Environment:** no hardcoded env values; no debug flags committed; document new env vars. `protocols/environment.md`
- **Run & demo:** maintain RUNBOOK.md from first runnable state; not done until the user has seen it run (or verifiably could). `protocols/run-demo.md`
- **Deployment:** opt-in only, never the default path; data-sensitivity gate before any deploy step. `protocols/deployment.md`
- **Edge cases:** missing pack files, no git, no file-read/write, placeholder conflicts, corrupt log → deterministic actions. `protocols/edge-cases.md`
- **Pack upgrade:** migrate a project to a newer pack version — replace pack-owned files, preserve project Part 2 + logs verbatim, on a branch. `protocols/upgrade.md`

---

## Protocol Index

All protocols, locations, and trigger conditions. **This is the only trigger
table in the pack.** Completeness check (used by edge-case handling and the
release checklist): compare `ls protocols/` against the rows below — every
file the index names must exist, and every file in protocols/ must have a
row. A mismatch in either direction is an error.

| Protocol | Location | When to load |
|----------|----------|-------------|
| Session Resumption | `protocols/session-start.md` | Type A — log exists |
| First Session | `protocols/session-start.md` | Type B — no log, no non-pack source files |
| Product Definition | `protocols/product-definition.md` | First session, user has an idea not a codebase (empty folder / stack unknown) |
| Run & Demo | `protocols/run-demo.md` | Closing a coding task (demo gate); backlog item done; run steps changed |
| Deployment | `protocols/deployment.md` | User asks to deploy/publish/share — opt-in only |
| Inherited Codebase | `protocols/inherited-codebase.md` | No log, non-pack source files present |
| Refactor | `protocols/refactor.md` | Explicit structural goal, no new features |
| Placeholder Inference | `protocols/placeholder-inference.md` | First session — fills REQUIRED placeholders (not in read-only) |
| Read-Only / Meta-Review | `protocols/read-only.md` | Review/audit/analysis — no edits intended |
| Communication Modes | `protocols/communication.md` | Audience detection; any non-dev session; any error shown to a non-dev |
| Enforcement Tooling | `protocols/enforcement-tooling.md` | Stack chosen / validation commands first set / walking skeleton |
| Secure Coding | `protocols/secure-coding.md` | Task touching input, authn/authz, sessions, stored data, file/path, or output |
| Independent Review | `protocols/review.md` | Backlog item done (before demo); before deploy; on request |
| Model Tiering | `protocols/model-tiering.md` | Deciding which model a delegated sub-agent task runs on |
| Decision Log & Handoff Format | `protocols/log-format.md` | Writing a log/handoff; reconstructing history; migrating CAPTAINS_LOG.md |
| Pre-Edit Protocol | `protocols/task-workflow.md` | Before every coding task (9-step checklist + checkpoint/rollback) |
| Task Brief & Prompt Reformulation | AGENTS.md + TASK_TEMPLATE.md | Every coding task; read-only exempt |
| Cross-Cutting Changes | `protocols/cross-cutting.md` | Task touches 3+ files, crosses layers, or moves/renames structurally |
| Safe Deletion | `protocols/safe-deletion.md` | Any file deletion request |
| Code Quality | `protocols/code-quality.md` | Writing/modifying code (not read-only or docs-only) |
| Environment Awareness | `protocols/environment.md` | Any environment-specific code or config |
| Context Window Management | `protocols/context-window.md` | 5+ tasks in session, or detected degradation |
| Sensitive Data Handling | `protocols/sensitive-data.md` | Inherited repos (scan) or on encounter |
| Stuck Loop Circuit Breaker | `protocols/stuck-loop.md` | 3 failed attempts on same problem |
| Validation Tooling Fallback | `protocols/validation-fallback.md` | Lint/test/CI missing or unconfigured |
| External Research Protocol | `protocols/external-research.md` | External SDK/API/platform work, version-sensitive or unverifiable |
| Knowledge Gap Protocol | `protocols/external-research.md` | Web unavailable, training data unverifiable |
| Binary & Large File Handling | `protocols/binary-files.md` | Binary files, or committing >1MB (threshold at commit-time) |
| Testing Strategy | `protocols/testing-strategy.md` | Writing/evaluating tests (not running an existing suite) |
| Conflict Resolution Examples | `protocols/conflict-examples.md` | Surfacing a conflict or verifying conflict behavior |
| Edge-Case Handling | `protocols/edge-cases.md` | Missing pack files, no git, no read/write, placeholder conflicts, corrupt log, version mismatch |
| Pack Upgrade / Migration | `protocols/upgrade.md` | User asks to upgrade/migrate a project to a newer pack version, or edge-cases version-mismatch handler routes here to migrate |
| Pattern Registry Maintenance | `protocols/pattern-registry.md` | Same approach in 2+ files this session, or a new approach replaced a buggy one |

---

## Authority Matrix

If two files appear to conflict on a topic, this table is authoritative:

| Topic | Authoritative source |
|-------|---------------------|
| Hard guardrails (what agent can never do) | AGENTS.md → Hard guardrails |
| Default policies (what requires confirmation) | AGENTS.md → Default policies |
| Verbal override rules | AGENTS.md → Instruction Precedence |
| Session start read order | AGENTS.md → Session Start |
| Which protocol file to load when | AGENTS.md → Protocol Index |
| Project-specific stack, commands, structure, style | AGENTS.md → Part 2 (Project Specifics) |
| Placeholder inference procedure | `protocols/placeholder-inference.md` |
| All detailed protocols | `protocols/` directory — one file per protocol |
| Current state & next task | `HANDOFF.md` (overwritten per task) |
| Session history and decisions | `DECISION_LOG.md` (append-only) |

When in doubt: AGENTS.md governs. `protocols/` files govern procedure detail.
`CLAUDE.md` is only the Claude Code import shim. Everything else is
human-facing documentation.

---

# Part 2 — Project Specifics (agent-maintained)

> **Bounded living summary rule:** Part 2 is rewritten to stay current, never
> grown append-only. Hard caps: Pattern Registry ≤ 40 lines, Project-Specific
> Architecture ≤ 60 lines, every other section at its template size. When an
> update would exceed a cap, compress: keep what a cold agent needs *now*;
> move superseded detail and decision history to the development log. The
> always-on context budget must not creep up as the project ages.
>
> **LEAN profile:** when Pack profile (Model Tiers) is LEAN, the Pattern
> Registry and Project-Specific Architecture sections collapse to a one-line
> pointer into DECISION_LOG.md instead of carrying the full sketch — the
> detail lives in the log and is read on demand. Everything else in Part 2
> stays as-is. This is the main local-context saving.

## Project Summary
<!-- Filled in by the agent during Placeholder Inference. -->

[PROJECT_NAME] is ...

## Audience Mode
<!-- Set by the agent at first session (audience detection); read at the start
     of every session. Values: Developer / Technical non-dev / Non-dev.
     Update only when the user asks for more or less explanation. -->

**Active mode:** [NOT SET — detect on first session per protocols/communication.md]

## Model Tiers
<!-- Set at stack selection (product-definition Step 3c / inherited-codebase
     Phase 3 step 4c). Read at session start (Pack profile — governs resident
     footprint + checkpoint cadence, protocols/context-window.md) and when
     delegating a sub-agent task (tier map — protocols/model-tiering.md).
     Provider/harness-agnostic. Tier map is single-tier whenever the Light row
     is "none" (every delegation runs on the Capable/session model). Fill "How
     to switch" with only the harness in use. Bounded: this block only. -->

**Pack profile:** [FULL — default; use LEAN for small-context/local runs (≤~16k). Governs resident footprint + checkpoint cadence per protocols/context-window.md]
**Context budget:** [NOT SET — approx usable context window, e.g. 8k / 16k / 32k / 200k]
**Provider / environment:** [NOT SET — e.g. Anthropic / OpenAI / Google / local Ollama / internal gateway]

| Role | Model | How to switch |
|------|-------|---------------|
| Capable (default — never downgraded) | [session/default model] | [where the model is pinned, e.g. `.claude/agents/*.md` `model:` / `.opencode/agent/*.md` `model:` / `.codex/agents/*.toml` `model`] |
| Light (bounded, rule-bound checks) | [cheaper/faster model, or — none → single-tier] | [predefine a Light subagent there; only Claude Code also allows a per-call `model`] |
| Deterministic | none (script only) | n/a |

## Quick Constraints
<!-- Filled in by the agent during Placeholder Inference. -->

- **[Language/runtime]** —
- **[Files not to edit]** —
- **[Lint command]** —
- **[Test command]** —

## Tech Stack & Constraints
<!-- ⚠️ REQUIRED PLACEHOLDER — filled by Placeholder Inference. -->

| Technology | Version / Constraint | Notes |
|-----------|---------------------|-------|
| Language | e.g., Python 3.10+ | |
| Runtime | e.g., Node 18+ | |
| Framework | e.g., React 18 | |
| Linter | e.g., ESLint, Ruff | |
| Formatter | e.g., Prettier, Black | |
| Tests | e.g., pytest, vitest | |

## Validation Commands
<!-- ⚠️ REQUIRED PLACEHOLDER — filled by Placeholder Inference.
     If genuinely unavailable, mark: # NOT CONFIGURED -->

```bash
# Lint
[INSERT LINT COMMAND]           # e.g., npm run lint, ruff check .

# Format check
[INSERT FORMAT COMMAND]         # e.g., npx prettier --check ., black --check .

# Type check (if applicable)
[INSERT TYPE CHECK COMMAND]     # e.g., npx tsc --noEmit, mypy .

# Test
[INSERT TEST COMMAND]           # e.g., npm test, pytest

# Build (if applicable)
[INSERT BUILD COMMAND]          # e.g., npm run build, make
```

**Rule: Run lint and tests after every change.** If a command is configured
above, run it after each edit and fix errors before committing.

## File Structure
<!-- ⚠️ REQUIRED PLACEHOLDER — filled by Placeholder Inference from the
     actual repo layout. -->

```
/                              # repo root
├── .claude/settings.json      # Claude Code permissions (enforcement layer)
├── .codex/config.toml         # Codex config (enforcement layer)
├── opencode.json              # OpenCode permissions (enforcement layer)
├── AGENTS.md                  # THIS FILE — single source of truth
├── CLAUDE.md                  # Claude Code import shim
├── protocols/                 # On-demand procedures
├── src/                       # source code
├── tests/                     # test files
└── docs/                      # documentation
```

## Safe-Edit Boundaries

**Agent-editable** — read and modify freely:
```
- src/**, tests/**, docs/**
- DECISION_LOG.md (append-only), HANDOFF.md (overwrite),
  BACKLOG.md, RUNBOOK.md          # agent maintains these
- AGENTS.md Part 2                # under the bounded-summary rule
```

**Restricted — explicit user instruction required:**
```
- AGENTS.md Part 1, CLAUDE.md, TASK_TEMPLATE.md, protocols/
  (pack policy — see Hard guardrails)
```

**Human-only or generated — never edit:**
```
- package-lock.json, yarn.lock, pnpm-lock.yaml   # auto-generated
- .env, .env.local, .env.production, secrets/**  # credential-bearing
  (.env.example / .env.template and non-secret config schema ARE safe to edit)
- dist/**, build/**, out/**                      # build output
- *.amxd, *.maxpat and other binaries            # edit in their GUI tools
# Add project-specific entries below:
- [file or glob]             # [reason]
```

**Schema and config changes:** additive where possible; destructive schema
operations are hard-guardrailed (never agent-executable); renames and
additive changes need explicit confirmation. Config changes documented in
the development log with before/after. Any required manual step is stated
before committing — never silently required. Rollback plan stated for any
schema or config change.

## Code Style
<!-- DEFERRED placeholder — default: the chosen stack's standard conventions
     (PEP 8, Prettier defaults, gofmt, etc.). The agent records only
     deviations and language rules here as they are decided — inferred from
     the codebase (inherited projects) or set with the stack choice (new
     projects). Generic code-quality rules live in protocols/code-quality.md
     and are NOT repeated here. -->

- Default: stack-standard conventions — record only deviations below
- No TODO/FIXME in committed code without a linked issue
- [naming/formatting/language rule, only if it deviates from stack default]

## Git Workflow

```bash
# Branch naming: feature/short-description, fix/short-description,
#                refactor/short-description
# Commit messages — imperative mood, concise:
#   "Add mode routing lookup table"        good
#   "Added stuff"                          bad
# Commit after each logical change (each completed task), not after each file.
```

## Task Prompts
<!-- DEFERRED — seeded by the developer or by the product-definition
     protocol as work is planned. -->

1. ...

## Related Docs & Projects
<!-- DEFERRED — filled if/when relevant. -->

| Doc / Project | Purpose / Relationship |
|---------------|------------------------|
| `README.md` | Human-facing pack documentation |
| `SETUP.md` | Human bootstrap walkthrough |

## Pattern Registry
<!-- Agent-maintained. HARD CAP: 40 lines. Check here before implementing
     anything; if a pattern exists, use it. Template and trigger rules:
     protocols/pattern-registry.md. When over cap: compress, keep current
     patterns, move history to the development log. LEAN profile: collapse to
     a one-line pointer into DECISION_LOG.md (see bounded living summary rule). -->

### [Pattern Name]
```
Purpose:      [What problem this pattern solves]
Location:     [Where to find the canonical example]
Usage:        [How to apply it]
Anti-pattern: [What NOT to do instead]
```

## Project-Specific Architecture
<!-- Agent-maintained. Set on DAY ONE — product-definition Step 3b (new
     projects, sized S1–S4) or Inherited Codebase Phase 3 (existing code,
     describe what IS there). HARD CAP: 60 lines. Growth triggers in
     product-definition govern revisits — logged, never silent drift.
     When over cap: compress to current structure + key invariants; move
     superseded detail to the development log. LEAN profile: collapse to a
     one-line pointer into DECISION_LOG.md (see bounded living summary rule). -->

### Size & Structure
```
[S1–S4 rung] — [WHY this size fits the brief]
[actual structure, one line per layer/module with its WHY]
```

### Data Flow
```
[how data moves through the system]
```

### Key Invariants
```
- [rules that, if broken, cause system-level failures]
```
